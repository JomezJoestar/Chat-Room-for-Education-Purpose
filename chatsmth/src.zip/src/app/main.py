from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import routers,meterial

app = FastAPI(title="Chat Rooms App")

origins = [
    # Add the URL where your React development server runs. 
    # Common ports are 3000, 5173 (Vite), 8080. Check your setup.
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    # If running on a different port, add it here: e.g., "http://localhost:5173"
]




app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],  # Add your frontend's URL here
    allow_credentials=True,
    allow_methods=["*"],  # Allow all HTTP methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
)


for r in routers:
    app.include_router(r)


app.include_router(meterial.router)

@app.get("/")
def root():
    return {"message": "Welcome to the Chat Rooms App"}
